import requests
from requests.sessions import session
import json
import time
import colorama
from colorama import Fore, Back, Style

colorama.init()

session = requests.session()

print(Fore.CYAN + """  
                        | TADIJA ON TOP |
                                                                          """)
print("")
print("")
print("TIKTOK: @dolazim / REPLIT: Tadijq ")

print("")
print("")

x = input('Report url (get it in the console) ')
print("")
print("")

print('Bot started ...')
print('')
print('')

while True:
    req = session.post(x)
    
    print(req.text)
    print('Reported [BY TADIJA LMAO]')

    time.sleep(10)


input()


